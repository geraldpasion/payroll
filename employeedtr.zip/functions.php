<?php

function get_fieldnames($tablename){
include 'dbconfig.php';

	$sql = "SHOW COLUMNS FROM $tablename";
	$result = mysqli_query($mysqli,$sql);
	while($row = mysqli_fetch_array($result)){
	//echo $row['Field']."<br>";
	//save it to an array
	$fields[]=$row['Field'];

	}

return $fields;
}//end get_fieldnames



function get_table($tablename){
	include 'dbconfig.php';
	?>
<div class="container">
		<table class='table table-responsive table-striped table-hover table-collapse' style="overflow: auto;">
			<tr>
				<?php
					$fields=get_fieldnames($tablename);
					foreach ($fields as $key => $value){
						echo '<th>'.$value.'</th>';
					}
				?>
			</tr>

			
				<?php
					$fields=get_fieldnames($tablename);
					
						$sql = "SELECT * FROM $tablename WHERE coaching_status='Pending'";
						$result = mysqli_query($mysqli,$sql);

						while($row = mysqli_fetch_array($result)){
							echo '<tr>';
							foreach ($fields as $key => $value){
								echo "<td>".$row[$value]."</td>";			
							}
							echo '</tr>';
						}
					
				?>
			
		</table>
</div>

	<?php
}
?>