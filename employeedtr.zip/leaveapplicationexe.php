<?php
include("dbconfig.php");
$leavetype = $_POST['leavetype1'];
$reason = $_POST['reason1'];
$empid = $_POST['empid1'];

if($_POST['date2']==""){
	unset($_POST['date2']);
}
if($_POST['date3']==""){
	unset($_POST['date3']);
}
if($_POST['date4']==""){
	unset($_POST['date4']);
}


if(isset($_POST['date1'])){
$date = $_POST['date1'];
$constart = substr($date, 0,10);
$conend = substr($date, 13,22);
$startdate = date("Y-m-d",strtotime($constart));
$enddate = date("Y-m-d",strtotime($conend));
if ($stmt = $mysqli->prepare("INSERT INTO tbl_leave (employee_id, leave_start, leave_reason, leave_type) VALUES ('$empid','$startdate', '$reason', '$leavetype')"))
{
	$stmt->execute();
	$stmt->close();
}
// show an error if the query has an error
else

{
	echo "ERROR: Could not prepare SQL statement.";
}

}

if(isset($_POST['date2'])){
$date1 = $_POST['date2'];
$constart1 = substr($date1, 0,10);
$conend1 = substr($date1, 13,22);
$startdate1 = date("Y-m-d",strtotime($constart1));
$enddate1 = date("Y-m-d",strtotime($conend1));

if ($stmt = $mysqli->prepare("INSERT INTO tbl_leave (employee_id, leave_start, leave_reason, leave_type) VALUES ('$empid','$startdate1', '$reason', '$leavetype')"))
{
	$stmt->execute();
	$stmt->close();
}
// show an error if the query has an error
else
{
	echo "ERROR: Could not prepare SQL statement.";
}
}

if(isset($_POST['date3'])){
$date2 = $_POST['date3'];
$constart2 = substr($date2, 0,10);
$conend2 = substr($date2, 13,22);
$startdate2 = date("Y-m-d",strtotime($constart2));
$enddate2 = date("Y-m-d",strtotime($conend2));
if ($stmt = $mysqli->prepare("INSERT INTO tbl_leave (employee_id, leave_start, leave_reason, leave_type) VALUES ('$empid','$startdate2', '$reason', '$leavetype')"))
{
	$stmt->execute();
	$stmt->close();
}
// show an error if the query has an error
else
{
	echo "ERROR: Could not prepare SQL statement.";
}
}


if(isset($_POST['date4'])){
$date3 = $_POST['date4'];
$constart3 = substr($date3, 0,10);
$conend3 = substr($date3, 13,22);
$startdate3 = date("Y-m-d",strtotime($constart3));
$enddate3 = date("Y-m-d",strtotime($conend3));
if ($stmt = $mysqli->prepare("INSERT INTO tbl_leave (employee_id, leave_start, leave_reason, leave_type) VALUES ('$empid','$startdate3', '$reason', '$leavetype')"))
{
	$stmt->execute();
	$stmt->close();
}
// show an error if the query has an error
else
{
	echo "ERROR: Could not prepare SQL statement.";
}
}
// insert the new record into the database

echo "Form Submitted Succesfully";
?>