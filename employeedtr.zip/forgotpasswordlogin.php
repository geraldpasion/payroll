<body>
			<div class="modal-header">
			<button type="button" class="close" data-dismiss="modal">&times;</button>
			<h2 style="text-align:center">Forgot Password?</h2>
<form action='forgotpasswordexe.php' method='post'>
			<table cellspacing='5' align='left'>
				<div class="modal-body">
					<h3 style="text-align:center">Enter your Username.</h3>
						<input type = "text" class = "form-control" placeholder = "Username" name = "username" required = "">
					<h3 style="text-align:center">Enter your E-mail Address.</h3>
						<input type = "email" class = "form-control" placeholder = "example@yahoo.com" name = "email" required = "">
				</div>
					<button type="button" class="btn btn-primary" data-dismiss="modal">&nbsp;&nbsp;Close&nbsp;&nbsp;</button>
					<button type="submit" name="submit" class="btn btn-primary">Submit</button>
			</table>
</form>

</body>
