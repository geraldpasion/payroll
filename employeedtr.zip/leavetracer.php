 <!DOCTYPE html>
<html>

	<head>
		<?php
			include('menuheader.php');
		?>
		<title>Leave Status</title>
	</head>

	<body>

		    <div class="row">

        <div class="col-lg-12">
        <div class="ibox float-e-margins">
        <div class="ibox-title">
            <h5>Leave Status</h5>
            <div class="ibox-tools">
                <a class="collapse-link">
                    <i class="fa fa-chevron-up"></i>
                </a>
                <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                    <i class="fa fa-wrench"></i>
                </a>
                <ul class="dropdown-menu dropdown-user">
                    <li><a href="#">Config option 1</a>
                    </li>
                    <li><a href="#">Config option 2</a>
                    </li>
                </ul>
                <a class="close-link">
                    <i class="fa fa-times"></i>
                </a>
            </div>
        </div>
 
            <div class="ibox-content">
                            <input type="text" class="form-control input-sm m-b-xs" id="filter"
                                   placeholder="Search in table">
				<?php
					include('dbconfig.php');

					if ($result = $mysqli->query("SELECT * FROM tbl_leave RIGHT JOIN employee ON employee.employee_id = tbl_leave.employee_id  WHERE leave_status = 'Approved' OR leave_status = 'Disapproved' ORDER BY leave_id DESC")) //get records from db
					{
						if ($result->num_rows > 0) //display records if any
						{
							echo "<table class='footable table table-stripped' data-page-size='20' data-filter=#filter>";								
							echo "<thead>";
							echo "<tr>";	
							echo "<th>Name</th>";
							echo "<th>Date</th>";
                     
                            echo "<th>Reason</th>";
							echo "<th>Type</th>";
							echo "<th>Status</th>";
							echo "<th>Remarks</th>";
							echo "<th>Managed by</th>";
							echo "</tr>";
							echo "</thead>";
							echo "<tfoot>";                    
								echo "<tr>";
								echo "<td colspan='9'>";
								echo "<ul class='pagination pull-right'></ul>";
								echo "</td>";
								echo "</tr>";
								echo "</tfoot>";
								
							while ($row = mysqli_fetch_object($result))
							{
								$leaveid = $row->leave_id;
								$empsid =$row->employee_id;
								echo "<tr>";
								echo "<td>" . $row->employee_firstname . " " . $row->employee_lastname . "</td>";
								echo "<td>" . date("Y-m-d",strtotime($row->leave_start)) . "</td>";
			
								echo "<td>" . $row->leave_reason . "</td>";
								echo "<td>" . $row->leave_type . "</td>";
								echo "<td>" . $row->leave_status . "</td>";
								echo "<td>" . $row->leave_remarks . "</td>";
								echo "<td>" . $row->leave_approvedby . "</td>";
								
								echo "<td> <a href = 'leaveappform.php?id=$empsid&leaveid=$leaveid'><button class='btn btn-success' type='button'><i class='fa fa-print'></i> Print</button></a></td>";
								echo "</tr>";

							}
							echo "</table>";

						}
						else 
						{if ($result1 = $mysqli->query("SELECT * FROM tbl_leave WHERE leave_status = 'Approved' OR leave_status = 'Disapproved' ORDER BY tbl_leave.leave_id DESC")) //get records from db
								{
									if ($result1->num_rows > 0) //display records if any
									{
										echo "<table class='footable table table-stripped toggle-arrow-tiny' data-page-size='20'>";								
										echo "<thead>";
										echo "<tr>";
										echo "<th data-toggle='true'>ID</th>";
										echo "<th>Name</th>";
										echo "</tr>";
										echo "</thead>";
										
										while ($row1 = mysqli_fetch_object($result1))
											
										{
											$empid = $row1->leave_id;
											echo "<tr class = 'josh'>";
											echo "<td>" . $row1->employee_id . "</td>";
											echo "<td>" . $row1->employee_lastname . "," . " " . $row1->employee_firstname . " " . $row1->employee_middlename . "</td>";
											echo "<td></td>";echo "</tr>";
										}
										
										echo "</table>";
									}}}
					}
				?>
				
			</div>
	
        </div>
        </div>
        </div>

    
		
		<?php
			include('menufooter.php');
		?>
	</body>
</html>