<?php

	$con= mysqli_connect('localhost','root','','payroll')or die("cannot connect");


?>