<?php 
	include("dbconfig.php");
	session_start();
	$attendanceid = $_POST['attendance_id'];
	$maxes2 = $_POST['attendance_id'];
	$date = date("Y-m-d",strtotime($_POST['logedit_date'])); 
	$timein = date("G:i",strtotime($_POST['logedit_timein']));
	$outfrombreak = date("G:i",strtotime($_POST['logedit_breakout']));
	$infrombreak = date("G:i",strtotime($_POST['logedit_breakin']));
	$timeout = date("G:i",strtotime($_POST['logedit_timeout']));
	$approvedby = $_SESSION['fname'] . " " . $_SESSION['lname'];

	$attendanceData = $mysqli->query("SELECT * FROM attendance WHERE attendance_id = '$maxes2'")->fetch_array();
	$employeeid = $attendanceData['employee_id'];
	$employeeData = $mysqli->query("SELECT * FROM employee WHERE employee_id = '$employeeid'")->fetch_array();
	$username = $employeeData['employee_id'];
	$password = $employeeData['employee_password'];

	$sel_user = "SELECT * from employee where employee_id='$username' AND employee_password='$password' AND employee_status = 'active'";
	$run_user = mysqli_query($mysqli, $sel_user);
	$fetch_emp = mysqli_fetch_array($run_user);

	$from = "edit";

	// insert the new record into the database
	if ($stmt = $mysqli->prepare("UPDATE attendance, logedit SET attendance.attendance_date = '$date', attendance.attendance_timein = '$timein', attendance.attendance_breakout = '$outfrombreak', attendance.attendance_breakin = '$infrombreak', attendance.attendance_timeout = '$timeout', logedit.logedit_status = 'Approved', logedit.logedit_approvedby = '$approvedby' WHERE logedit.attendance_id = '$attendanceid' AND attendance.attendance_id = '$attendanceid'"))
	{
		$stmt->execute();
		$stmt->close();
		include("updateattendance.php");
	}
	// show an error if the query has an error
	else
	{
		echo "ERROR: Could not prepare SQL statement.";
	}
	// redirec the user
	header("Location: attendance2.php?edited");
?>