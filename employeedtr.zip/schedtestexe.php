<?php 
include("dbconfig.php");
$str_explode=explode("-",$_POST["daterange"]);
$string1 = $str_explode[0];
$string2 = $str_explode[1];

$usersCount = count($_POST["id"]);
for($i=0;$i<$usersCount;$i++) {

if ($stmt = $mysqli->prepare("UPDATE employee set employee_shift='" . $_POST["sched"] . "',date_start='".$string1."',date_end='".$string2."' WHERE employee_id='" . $_POST["id"][$i] . "'"))
{
	$stmt->execute();
	$stmt->close();
}
// show an error if the query has an error
else
{
	echo "ERROR: Could not prepare SQL statement.";
}
}
?>