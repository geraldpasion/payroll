<?php
include("dbconfig.php");
session_start();
$attendance_id = $_POST['attendance_id'];
$employee_id = $_SESSION['logsession'];
$logedit_timein = $_POST['logedit_timein'];
$logedit_timein = str_replace(' ', '', $logedit_timein);
$logedit_timein = substr_replace($logedit_timein, '', 5, 1);
$logedit_timein = date("H:i", strtotime($logedit_timein));
$logedit_breakout = $_POST['logedit_breakout'];
$logedit_breakout = str_replace(' ', '', $logedit_breakout);
$logedit_breakout = substr_replace($logedit_breakout, '', 5, 1);
$logedit_breakout = date("H:i", strtotime($logedit_breakout));
$logedit_breakin = $_POST['logedit_breakin'];
$logedit_breakin = str_replace(' ', '', $logedit_breakin);
$logedit_breakin = substr_replace($logedit_breakin, '', 5, 1);
$logedit_breakin = date("H:i", strtotime($logedit_breakin));
$logedit_timeout = $_POST['logedit_timeout'];
$logedit_timeout = str_replace(' ', '', $logedit_timeout);
$logedit_timeout = substr_replace($logedit_timeout, '', 5, 1);
$logedit_timeout = date("H:i", strtotime($logedit_timeout));
$logedit_reason = $_POST['logedit_reason'];
$logedit_date = date("Y-m-d",strtotime($_POST['logedit_date'])); 

// insert the new record into the database
if ($stmt = $mysqli->prepare("INSERT INTO logedit (attendance_id, employee_id, logedit_date, logedit_timein, logedit_breakout, logedit_breakin, logedit_timeout, logedit_reason) VALUES ('$attendance_id', '$employee_id', '$logedit_date', '$logedit_timein', '$logedit_breakout', '$logedit_breakin', '$logedit_timeout', '$logedit_reason') ON DUPLICATE KEY UPDATE employee_id = '$employee_id', logedit_date = '$logedit_date', logedit_timein = '$logedit_timein', logedit_breakout = '$logedit_breakout', logedit_breakin = '$logedit_breakin', logedit_timeout = '$logedit_timeout', logedit_reason = '$logedit_reason', logedit_status = 'Pending'"))
{
	$stmt->execute();
	$stmt->close();
}
// show an error if the query has an error
else
{
	echo "ERROR: Could not prepare SQL statement.";
}

?>