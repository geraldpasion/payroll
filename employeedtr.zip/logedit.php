<!DOCTYPE html>
<html>
	<head>
		<?php
			include('menuheader.php');
		?>
		<title>Log Edit Requests</title>
		<style>
			.btn3{
				margin-left:13em;
			}
			.btn2{
				margin-left:2.5em;
			}
			.clockpicker-popover{
    z-index: 9999;
}
		</style>
		<link href="css/plugins/clockpicker/clockpicker.css" rel="stylesheet">
		<!-- Clock picker -->
		<script src="js/plugins/clockpicker/clockpicker.js"></script>
		<script type="text/javascript">
			$(function() {
				$('input[name="daterange"]').daterangepicker({
					singleDatePicker: true,
					showDropdowns: true
				});
			});
		</script>
		<script type="text/javascript">
			$(function() {
			$(".approve").click(function(){
			var element = $(this);
			var attendance_id = element.attr("id");
			var date = element.attr("date");
			var timein = element.attr("timein");
			var breakout = element.attr("breakout");
			var breakin = element.attr("breakin");
			var timeout = element.attr("timeout");
			var info = 'attendance_id=' + attendance_id + '&logedit_date='+ date + '&logedit_timein='+ timein + '&logedit_breakout='+ breakout + '&logedit_breakin='+ breakin + '&logedit_timeout='+ timeout;
			
			 $.ajax({
			   type: "POST",
			   url: "logeditexe.php",
			   data: info,
			   success: function(){
			 }
			});
			  $(this).parents(".josh").remove();
			 $(window).scrollTop(0);
			 toastr.options = { 
				"closeButton": true,
			  "debug": false,
			  "progressBar": true,
			  "preventDuplicates": true,
			  "positionClass": "toast-top-right",
			  "onclick": null,
			  "showDuration": "400",
			  "hideDuration": "1000",
			  "timeOut": "7000",
			  "extendedTimeOut": "1000",
			  "showEasing": "swing",
			  "hideEasing": "linear",
			  "showMethod": "fadeIn",
			  "hideMethod": "fadeOut" // 1.5s
				}
				toastr.success("Log edit request approved!");
			return false;
			});
			});
		</script>
				<script type="text/javascript">
			$(function() {
			$(".delete").click(function(){
			var element = $(this);
			var attendance_id = element.attr("id");
			var info = 'attendance_id=' + attendance_id;
			 $.ajax({
			   type: "POST",
			   url: "disapprovelogedit.php",
			   data: info,
			   success: function(){
			 }
			});
			  $(this).parents(".josh").remove();
				toastr.options = { 
				"closeButton": true,
				"debug": false,
				"progressBar": true,
				"preventDuplicates": false,
				"positionClass": "toast-top-right",
				"onclick": null,
				"showDuration": "400",
				"hideDuration": "1000",
				"timeOut": "7000",
				"extendedTimeOut": "1000",
				"showEasing": "swing",
				"hideEasing": "linear",
				"showMethod": "fadeIn",
				"hideMethod": "fadeOut" // 1.5s
				}
				toastr.success('Log edit request disapproved!');
			return false;
			});
			});
		</script>
		<script type="text/javascript">
		$(document).ready(function(){
			 showEdited=function(){
		toastr.options = { 
				"closeButton": true,
			  "debug": false,
			  "progressBar": true,
			  "preventDuplicates": true,
			  "positionClass": "toast-top-right",
			  "onclick": null,
			  "showDuration": "400",
			  "hideDuration": "1000",
			  "timeOut": "7000",
			  "extendedTimeOut": "1000",
			  "showEasing": "swing",
			  "hideEasing": "linear",
			  "showMethod": "fadeIn",
			  "hideMethod": "fadeOut" // 1.5s
				}
				toastr.success("Successfully edited attendance!");
				history.replaceState({}, "Title", "attendance.php");
		}
		
		
	});
	</script>
	<?php
		if(isset($_GET['edited']))
		{
			echo '<script type="text/javascript">'
					, '$(document).ready(function(){'
					, 'showEdited();'
					, '});' 
			   
			   , '</script>'
			;	
		}
		?>
	</head>
	<body>
		<div class="row">
			<div class="col-lg-12">
				<div class="ibox float-e-margins">
					<div class="ibox-title">
						<h5>Employee DTR</h5>
						<div class="ibox-tools">
							<a class="collapse-link">
								<i class="fa fa-chevron-up"></i>
							</a>
							<a class="dropdown-toggle" data-toggle="dropdown" href="#">
								<i class="fa fa-wrench"></i>
							</a>
							<ul class="dropdown-menu dropdown-user">
								<li><a href="#">Config option 1</a>
								</li>
								<li><a href="#">Config option 2</a>
								</li>
							</ul>
							<a class="close-link">
								<i class="fa fa-times"></i>
							</a>
						</div>
					</div>
					<div class="ibox-content">
						<input type="text" class="form-control input-sm m-b-xs" id="filter" placeholder="Search in table">
						<?php
							include('dbconfig.php');
								if ($result = $mysqli->query("SELECT * FROM logedit INNER JOIN employee ON employee.employee_id = logedit.employee_id WHERE logedit_status ='Pending'")) //get records from db
								{
									if ($result->num_rows > 0) //display records if any
									{
										echo "<table class='footable table table-stripped' data-page-size='8' data-filter=#filter>";								
										echo "<thead>";
										echo "<tr>";
										echo "<th>Name</th>";
										echo "<th>Date</th>";
										echo "<th>Time in</th>";
										echo "<th>Out from break</th>";
										echo "<th>In from break</th>";
										echo "<th>Time out</th>";
										echo "<th>Action</th>";
										echo "</tr>";
										echo "</thead>";
										echo "<tfoot>";                    
										echo "<tr>";
										echo "<td colspan='78'>";
										echo "<ul class='pagination pull-right'></ul>";
										echo "</td>";
										echo "</tr>";
										echo "</tfoot>";
										while ($row = $result->fetch_object())
										{
											echo "<tr class = 'josh'>";
											echo "<td>" . $row->employee_firstname . " " . $row->employee_lastname . "</td>";
											echo "<td>" . date("Y-m-d",strtotime($row->logedit_date)) . "</td>";
											echo "<td>" . date("g:i A",strtotime($row->logedit_timein)) . "</td>";
											echo "<td>" . date("g:i A",strtotime($row->logedit_breakout)). "</td>";
											echo "<td>" . date("g:i A",strtotime($row->logedit_breakin)) . "</td>";
											echo "<td>" . date("g:i A",strtotime($row->logedit_timeout)) . "</td>";
											echo "<td><a href='#' id = '$row->attendance_id' date='$row->logedit_date' timein='$row->logedit_timein' class = 'approve'
																timein='$row->logedit_timein' 
																breakout='$row->logedit_breakout' 
																breakin='$row->logedit_breakin' 
																timeout='$row->logedit_timeout' 
											
											
										><button class='btn btn-success' name = 'edit' type='button'><i class='fa fa-paste'></i> Approve</button></a>&nbsp;&nbsp;";
										
										echo "<a href='#' id = '$row->attendance_id' class = 'delete'><button class='btn btn-danger' type='button'><i class='fa fa-warning'></i> Disapprove</button></button></a>";
											echo "</tr>";
										}
										echo "</table>";
									}
								}
							
						?>
					</div>
				</div>
			</div>
        </div>
	
		<script type="text/javascript">
			$('.clockpicker').clockpicker();
		</script>
		<?php
			include('menufooter.php');
		?>
	</body>
</html>