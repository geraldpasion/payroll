<?php

require_once 'excel/PHPExcel_1.8.0_doc/Classes/PHPExcel.php'


?>

<form action="downloadexcelfile.php">
	<input type="submit" value="Download Excel">

</form>